import random
import json

STATE_INIT = 0
STATE_GENERATE_MESSAGES = 1
STATE_ENGAGE_WITH_USER = 2
STATE_COACHING = 3

class InteractionController():

    def __init__(self, ui, llm_api):
        self.ui = ui
        self.llm_api = llm_api

        self.state = STATE_INIT

    # Constructs a prompt with appropriate context, sends the user query to the LLM and returns the response
    def user_query(self, query, message):

        response = ""
        prompt = ""

        templates = self.llm_api.get_prompt_templates()

        if self.state == STATE_INIT:
            prompt_template = templates.get("conversation-training-context")
            prompt = prompt_template.format(query=query)

        elif self.state == STATE_GENERATE_MESSAGES:
            response = "Messages are being generated. One moment please."

        elif self.state == STATE_ENGAGE_WITH_USER:
            if message:
                # A message is visible
                prompt_template = templates.get("conversation-phishing-context-with-message")
                prompt = prompt_template.format(query=query, subject=message["subject"], sender=message["sender"], content=message["content"])
            else:
                # No message is visible
                prompt_template = templates.get("conversation-training-context")
                prompt = prompt_template.format(query=query)

        elif self.state == STATE_COACHING:
            prompt_template = templates.get("conversation-phishing-context-with-message")
            prompt = prompt_template.format(query=query, subject=message["subject"], sender=message["sender"], content=message["content"])
        
        if prompt:
            response = self.llm_api.llm_local_query(prompt)

        return response
    
    def enter_state_generate_messages(self):
        self.state = STATE_GENERATE_MESSAGES
        self.llm_api.reset_conversation()

    def enter_state_engage_with_user(self):
        self.state = STATE_ENGAGE_WITH_USER
        self.llm_api.reset_conversation()

    def enter_state_coaching(self):
        self.state = STATE_COACHING

    def get_state(self):
        return self.state
    
    def is_in_init_state(self):
        return self.state == STATE_INIT

    def is_in_generate_messages_state(self):
        return self.state == STATE_GENERATE_MESSAGES
    
    def is_in_engagte_with_user_state(self):
        return self.state == STATE_ENGAGE_WITH_USER
    
    def is_in_coaching_state(self):
        return self.state == STATE_COACHING
    
    # report the user decision on a message and returns the response of the coach
    def flag_message(self, message, is_phishing_actual, is_phishing_user_decision):

        templates = self.llm_api.get_prompt_templates()

        prompt_template = ""

        if is_phishing_actual and is_phishing_user_decision:
            prompt_template = templates.get("coaching-true-positive")
        elif not is_phishing_actual and is_phishing_user_decision:
            prompt_template = templates.get("coaching-false-positive")
        elif is_phishing_actual and not is_phishing_user_decision:
            prompt_template = templates.get("coaching-false-negative")
        elif not is_phishing_actual and not is_phishing_user_decision:
            prompt_template = templates.get("coaching-true-negative")
        
        prompt = prompt_template.format(subject=message.get("subject"), sender=message.get("sender"), content=message.get("content"), analysis=message.get("analysis"))
        #response = self.user_query(prompt, message)
        response = self.llm_api.llm_local_query(prompt)

        return response
