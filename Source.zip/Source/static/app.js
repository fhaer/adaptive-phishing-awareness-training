class Chatbox {
    constructor() {
        this.args = {
            openButton: document.querySelector('.chatbox__button'),
            chatBox: document.querySelector('.chatbox__support'),
            sendButton: document.querySelector('.send__button')
        }

        this.state = false;
        this.messages = [];

        this.chatboxContainer = document.querySelector('.chatbox__support');
        this.sendButton = document.querySelector('.send__button');
    }

    display() {
        const {openButton, chatBox, sendButton} = this.args;

        openButton.addEventListener('click', () => this.toggleState(chatBox))
        sendButton.addEventListener('click', () => this.onSendButton(chatBox))
    
        const node = chatBox.querySelector('input');
        node.addEventListener("keyup", ({key}) => {
            if (key === "Enter") {
                this.onSendButton(chatBox)
            }
        })
    }

    toggleState(chatbox) {
        this.state = !this.state;

        // show or hides the box
        if(this.state) {
            chatbox.classList.add('chatbox--active')
        } else {
            chatbox.classList.remove('chatbox--active')
        }
    }

    handleAction(action, messageId) {
        let message;
        let is_phishing = false;
        if (action === "report") {
            is_phishing = true;
        }

        // Open chatbox
        if (!this.chatboxContainer.classList.contains('chatbox--active')) {
            this.chatboxContainer.classList.add('chatbox--active');
        }

        var textField = this.chatboxContainer.querySelector('input');
        textField.disabled = true;
        this.sendButton.disabled = true;

        let user_message = { name: "User", message: "Flag as Legitimate" }
        if (is_phishing) {
            user_message = { name: "User", message: "Flag as Phishing" }
        }
        this.messages.push(user_message);

        let msgLoading = { name: "Coach", message: "Generating ..." };
        this.messages.push(msgLoading);
        this.updateChatText(this.chatboxContainer); 

        // Delay fetch slightly to allow the UI to update
        setTimeout(() => {
            fetch('/messages/flag', {
                method: 'POST',
                mode: 'cors',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ "message_id": messageId, "is_phishing": is_phishing })
            })
            .then(r => r.json())
            .then(r => {
                // Remove "Generating ..." and add actual response
                this.messages.pop(); // Remove last message (Generating ...)
                let msg2 = { name: "Coach", message: r.response };
                this.messages.push(msg2);
                this.updateChatText(this.chatboxContainer);
                textField.value = '';
            })
            .catch((error) => {
                console.error('Error:', error);
                this.messages.pop(); // Remove "Generating ..."
                this.messages.push({ name: "Coach", message: "An error occurred. Please try again." });
                this.updateChatText(this.chatboxContainer);
            })
            .finally(() => {
                this.sendButton.disabled = false; // Re-enable
                textField.disabled = false;
            });
        }, 0);

    }

    appendMessageUser(content) {
        const chatMessageContainer = document.querySelector('.chatbox__messages > div');
        const messageContainer = document.querySelector('.chatbox__messages > div');

        const messageElement = document.createElement('div');
        messageElement.classList.add('messages__item', 'messages__item--visitor');
        messageElement.innerText = content;

        messageContainer.appendChild(messageElement);
    }

    appendMessageCoach(content) {
        const chatMessageContainer = document.querySelector('.chatbox__messages > div');
        const messageContainer = document.querySelector('.chatbox__messages > div');

        const messageElementResp = document.createElement('div');
        messageElementResp.classList.add('messages__item', 'messages__item--operator');
        messageElementResp.innerText = content;

        messageContainer.appendChild(messageElementResp);
        return messageElementResp;
    }

    onSendButton(chatbox) {
        var textField = chatbox.querySelector('input');
        let user_query = textField.value
        if (user_query === "") {
            return;
        }

        let msg1 = { name: "User", message: user_query }
        this.messages.push(msg1);

        const visibleEmail = document.querySelector('.visible-email');
        const email_id = visibleEmail ? visibleEmail.id : undefined;
        
        this.sendButton.disabled = true;
        textField.disabled = true;
        let msgLoading = { name: "Coach", message: "Generating ..." };
        this.messages.push(msgLoading);
        this.updateChatText(chatbox); 

        // Delay fetch slightly to allow the UI to update
        setTimeout(() => {
            fetch('/query', {
                method: 'POST',
                mode: 'cors',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ "user_query": user_query, "email_id": email_id })
            })
            .then(r => r.json())
            .then(r => {
                // Remove "Generating ..." and add actual response
                this.messages.pop(); // Remove last message (Generating ...)
                let msg2 = { name: "Coach", message: r.response };
                this.messages.push(msg2);
                this.updateChatText(chatbox);
                textField.value = '';
            })
            .catch((error) => {
                console.error('Error:', error);
                this.messages.pop(); // Remove "Generating ..."
                this.messages.push({ name: "Coach", message: "An error occurred. Please try again." });
                this.updateChatText(chatbox);
            })
            .finally(() => {
                this.sendButton.disabled = false; // Re-enable
                textField.disabled = false;
            });
        }, 0);
    }

    updateChatText(chatbox) {
        var html = '<div>';
        this.messages.slice().forEach(function(item, index) {
            if (item.name === "User")
            {
                html += '<div class="messages__item messages__item--visitor">' + item.message + '</div>'
            }
            else
            {
                html += '<div class="messages__item messages__item--operator">' + item.message + '</div>'
            }
          });
        html += "</div>"
        
        const chatmessage = chatbox.querySelector('.chatbox__messages');
        chatmessage.innerHTML = html;
    }
}

class EmailHandler {
    constructor() {
        this.emailListContainer = document.querySelector(".email-list");
        this.emailContentContainer = document.querySelector(".email-content");
    }

    loadEmails() {

        function truncateText(text, maxLength = 54) {
            return text.length > maxLength ? text.slice(0, maxLength) + " ..." : text;
        }

        function truncateAfterParenthesis(text) {
            let index = text.indexOf("(");
            return index !== -1 ? text.slice(0, index).trim() : text;
        }

        const fetchNext = () => {  // Use an arrow function
            fetch("/messages/get")
                .then(response => response.json())
                .then(data => {
                    if (data.messages.length === 0) {
                        console.log("No more messages to fetch.");
                        document.getElementById("generating").style.display = "none";
                        document.getElementById("starting").style.display = "block";
                        return;
                    }
                    data.messages.forEach((email, index) => {

                        // Check the data
                        if (!email || !email.sender || !email.subject || !email.content) {
                            console.warn("Skipping invalid email:", email);
                            return;
                        }                        
                        // Check if the element already exists
                        if (document.getElementById(email.id)) {
                            console.log(`Email with ID ${email.id} is already added.`);
                            return; 
                        }

                        // Create email list item
                        const inboxItemId = `inbox-entry-${email.id}`
                        const inboxItem = document.createElement("div");
                        inboxItem.className = "email-item";
                        inboxItem.id = inboxItemId;
                        inboxItem.onclick = () => this.showEmail(email.id);  // `this` now refers to class instance
                        inboxItem.innerHTML = `<h3>${truncateAfterParenthesis(email.sender)}</h3><p>` + truncateText(email.subject) + `</p>`;
                        this.emailListContainer.appendChild(inboxItem);
    
                        // Create email content div
                        const emailDetail = document.createElement("div");
                        emailDetail.id = email.id;
                        emailDetail.className = "email-detail";
                        emailDetail.style.display = "none";
                        emailDetail.innerHTML = `
                            <h3 style="color: black; border-bottom: 2px solid black; padding-bottom: 5px;">${email.subject}</h3>
                            <h4 class="email-sender" style="margin-top: 10px;">
                                <img src="https://img.icons8.com/color/48/000000/email.png" alt="Email Icon">Sender: ${email.sender}
                            </h4>
                            <p style="margin-top: 20px;">${email.content}</p>
                            <div style="margin-top: 20px;">
                                <button class="btn btn-danger" onclick="chatbox.handleAction('report', '${email.id}')">Flag as Phishing</button>
                                <button class="btn btn-success" onclick="chatbox.handleAction('allow', '${email.id}')">Flag as Legitimate</button>
                            </div>
                        `;
                        this.emailContentContainer.appendChild(emailDetail);
                    });
                    if (!data.generation_completed) {
                        // Get new messages
                        new Promise(r => setTimeout(r, 100)).then(t => fetchNext());
                    } else {
                        document.getElementById("generating").style.display = "none";
                        document.getElementById("starting").style.display = "block";
                    }
                })
                .catch(error => console.error("Error loading emails:", error));
        };

        // Start the function
        fetchNext(); 
    }
    

    showEmail(emailId) {
        document.getElementById('starting').style.display = 'none';

        const inboxItemId = `inbox-entry-${emailId}`
        document.querySelectorAll('.email-item').forEach(email => email.classList.remove('active'));
        document.getElementById(inboxItemId).classList.add('active');

        document.querySelectorAll('.email-detail').forEach(email => {email.style.display = 'none'; email.classList.remove('visible-email')});
        document.getElementById(emailId).style.display = 'block';
        document.getElementById(emailId).classList.add('visible-email');

        fetch('/messages/show', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ "email_id": emailId })
        }).catch(error => console.error('Error:', error));
    }

}

// Initialize EmailHandler
const emailHandler = new EmailHandler();
document.addEventListener("DOMContentLoaded", () => emailHandler.loadEmails());

// Initialize Chatbox
const chatbox = new Chatbox();
chatbox.display();
